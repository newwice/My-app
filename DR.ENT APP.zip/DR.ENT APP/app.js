document.addEventListener('DOMContentLoaded', function() {
    // تهيئة التطبيق
    initApp();
});

function initApp() {
    // إعداد أحداث النقر على روابط التنقل
    setupNavigation();

    // إعداد نماذج الإدخال
    setupForms();

    // إعداد وظائف الاستشارات
    setupConsultations();

    // إعداد وظائف لوحة تحكم الطبيب
    setupDoctorDashboard();

    // إعداد وظائف التقارير
    setupReports();
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            showSection(targetId);
        });
    });
}

function showSection(sectionId) {
    const sections = document.querySelectorAll('main section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

function setupForms() {
    const loginForm = document.getElementById('login-form');
    const patientFileForm = document.getElementById('patient-file-form');
    const appointmentForm = document.getElementById('appointment-form');

    loginForm.addEventListener('submit', handleLogin);
    patientFileForm.addEventListener('submit', handlePatientFileSave);
    appointmentForm.addEventListener('submit', handleAppointmentBooking);
}

function handleLogin(e) {
    e.preventDefault();
    const username = e.target.username.value;
    const password = e.target.password.value;
    
    // تشفير كلمة المرور قبل إرسالها
    const encryptedPassword = CryptoJS.AES.encrypt(password, 'secret_key').toString();

    // إرسال بيانات تسجيل الدخول إلى الخادم (محاكاة)
    console.log('تم إرسال بيانات تسجيل الدخول:', { username, encryptedPassword });
    alert('تم تسجيل الدخول بنجاح');
    showSection('patient-file');
}

function handlePatientFileSave(e) {
    e.preventDefault();
    const patientData = {
        name: e.target.name.value,
        birthdate: e.target.birthdate.value,
        phone: e.target.phone.value,
        medicalHistory: e.target.medical_history.value,
        examinationResults: e.target.examination_results.value,
        diagnosis: e.target.diagnosis.value,
        treatmentPlan: e.target.treatment_plan.value
    };

    // تشفير البيانات الحساسة
    const encryptedData = encryptSensitiveData(patientData);

    // إرسال البيانات المشفرة إلى الخادم (محاكاة)
    console.log('تم إرسال بيانات المريض المشفرة:', encryptedData);
    alert('تم حفظ الملف الطبي بنجاح');
}

function handleAppointmentBooking(e) {
    e.preventDefault();
    const appointmentData = {
        service: e.target.service.value,
        doctor: e.target.doctor.value,
        date: e.target.appointment_date.value
    };

    // إرسال بيانات الموعد إلى الخادم (محاكاة)
    console.log('تم إرسال بيانات الموعد:', appointmentData);
    alert('تم حجز الموعد بنجاح');
    showPaymentOptions();
}

function showPaymentOptions() {
    const paymentOptions = [
        { name: 'مدى', icon: 'mada-icon.png' },
        { name: 'فيزا', icon: 'visa-icon.png' },
        { name: 'آبل باي', icon: 'apple-pay-icon.png' },
        { name: 'STC Pay', icon: 'stc-pay-icon.png' },
        { name: 'تابي', icon: 'tabby-icon.png' },
        { name: 'تمارا', icon: 'tamara-icon.png' }
    ];

    const paymentContainer = document.getElementById('payment-options');
    paymentContainer.innerHTML = paymentOptions.map(option => 
        `<button class="payment-btn" onclick="processPayment('${option.name}')">
            <img src="${option.icon}" alt="${option.name}"> ${option.name}
        </button>`
    ).join('');
}

function processPayment(method) {
    // معالجة الدفع (محاكاة)
    console.log(`تمت معالجة الدفع باستخدام ${method}`);
    alert(`تم الدفع بنجاح باستخدام ${method}`);
}

function setupConsultations() {
    const sendMessageBtn = document.getElementById('send-message');
    const startVideoCallBtn = document.getElementById('start-video-call');

    sendMessageBtn.addEventListener('click', sendMessage);
    startVideoCallBtn.addEventListener('click', startVideoCall);
}

function sendMessage() {
    const chatInput =